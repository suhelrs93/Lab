// Q.1 Write a Java program to print 'Hello' on screen and then print your details on a separate line.

class Hello{

public static void main( String args[]){

System.out.println("Hello");

}

}